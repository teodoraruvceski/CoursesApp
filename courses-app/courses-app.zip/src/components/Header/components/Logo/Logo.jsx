import React from 'react';
import logo from './logo.jpg';

function Logo() {
  return <img width={100} height={100} src={logo} alt="logo" />;
}

export default Logo;
